package okhi;

public enum OkHiDevMode { SANDBOX, PRODUCTION }
