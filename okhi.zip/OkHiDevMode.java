package okhi;

enum OkHiDevMode { SANDBOX, PRODUCTION }
