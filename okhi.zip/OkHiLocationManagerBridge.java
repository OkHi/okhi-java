package okhi;

public interface OkHiLocationManagerBridge {
  public String name = null;
  public void receiveMessage(String message);
}
