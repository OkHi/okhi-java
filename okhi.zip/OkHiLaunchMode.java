package okhi;

public enum OkHiLaunchMode {
  START_APP,
  SELECT_LOCATION
}